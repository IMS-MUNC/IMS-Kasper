const express = require('express');
const router = express.Router();
const { createCreditNote, getAllCreditNotes,getAllCreditNotesBySale } = require('../controllers/creditNoteController');

router.post('/return', createCreditNote);
// Add more routes as needed (get, list, etc.)
router.get('/all', getAllCreditNotes);
router.get('/sale/:saleId', getAllCreditNotesBySale);

module.exports = router;
